package com.example.sync;

class Counter {
    private int count = 0;

    // Without synchronization (race condition)
    public void increment() {
        count++;
    }

    public int getCount() {
        return count;
    }
}

class SyncCounter {
    private int count = 0;

    // With synchronization (solution)
    public synchronized void increment() {
        count++;
    }

    public int getCount() {
        return count;
    }
}

public class RaceConditionDemo {

    public static void main(String[] args) throws InterruptedException {

        // --- Race Condition Example ---
        Counter counter = new Counter();

        Thread t1 = new Thread(() -> {
            for (int i = 0; i < 1000; i++) counter.increment();
        });

        Thread t2 = new Thread(() -> {
            for (int i = 0; i < 1000; i++) counter.increment();
        });

        t1.start();
        t2.start();
        t1.join();
        t2.join();

        System.out.println("Without Synchronization: " + counter.getCount());

        // --- Synchronized Example ---
        SyncCounter syncCounter = new SyncCounter();

        Thread t3 = new Thread(() -> {
            for (int i = 0; i < 1000; i++) syncCounter.increment();
        });

        Thread t4 = new Thread(() -> {
            for (int i = 0; i < 1000; i++) syncCounter.increment();
        });

        t3.start();
        t4.start();
        t3.join();
        t4.join();

        System.out.println("With Synchronization: " + syncCounter.getCount());
    }
}
