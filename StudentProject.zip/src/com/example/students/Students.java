package com.example.students;

public class Students {
    private String name;
    private int age;
    private String studentId;

    public Students(String name, int age, String studentId) {
        this.name = name;
        this.age = age;
        this.studentId = studentId;
    }

    public void displayDetails() {
        System.out.println("\nStudent ID: " + studentId);
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
    }
}
