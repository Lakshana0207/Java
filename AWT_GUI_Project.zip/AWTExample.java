
import java.awt.*;
import java.awt.event.*;

public class AWTExample extends Frame implements ActionListener {

    Label l1, l2, result;
    TextField t1, t2;
    Button addBtn;

    AWTExample() {
        setTitle("AWT Calculator");
        setLayout(new FlowLayout());

        l1 = new Label("Enter Number 1:");
        t1 = new TextField(10);

        l2 = new Label("Enter Number 2:");
        t2 = new TextField(10);

        addBtn = new Button("Add");
        result = new Label("Result: ");

        add(l1); add(t1);
        add(l2); add(t2);
        add(addBtn);
        add(result);

        addBtn.addActionListener(this);

        setSize(300,200);
        setVisible(true);

        addWindowListener(new WindowAdapter(){
            public void windowClosing(WindowEvent e){
                dispose();
            }
        });
    }

    public void actionPerformed(ActionEvent e) {
        try {
            int a = Integer.parseInt(t1.getText());
            int b = Integer.parseInt(t2.getText());
            int sum = a + b;
            result.setText("Result: " + sum);
        } catch(Exception ex) {
            result.setText("Invalid Input");
        }
    }

    public static void main(String[] args) {
        new AWTExample();
    }
}
