AWT GUI Project

Steps to Run:
1. Open Command Prompt in this folder
2. Compile: javac AWTExample.java
3. Run: java AWTExample
