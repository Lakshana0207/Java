package com.example.student;

import java.io.*;
import java.util.*;

public class InventoryManager {

    private static final String FILE_NAME = "inventory.ser";
    private List<InventoryItem> inventory;

    public InventoryManager() {
        inventory = loadInventory();
    }

    public void addItem(int id, String name, int quantity) {
        for (InventoryItem item : inventory) {
            if (item.getId() == id) {
                System.out.println("Item already exists");
                return;
            }
        }
        inventory.add(new InventoryItem(id, name, quantity));
        saveInventory();
        System.out.println("Item added");
    }

    public void updateItem(int id, int quantity) {
        for (InventoryItem item : inventory) {
            if (item.getId() == id) {
                item.setQuantity(quantity);
                saveInventory();
                System.out.println("Item updated");
                return;
            }
        }
        System.out.println("Item not found");
    }

    public void deleteItem(int id) {
        Iterator<InventoryItem> it = inventory.iterator();
        while (it.hasNext()) {
            InventoryItem item = it.next();
            if (item.getId() == id) {
                it.remove();
                saveInventory();
                System.out.println("Item deleted");
                return;
            }
        }
        System.out.println("Item not found");
    }

    public void displayItems() {
        for (InventoryItem item : inventory) {
            System.out.println(item);
        }
    }

    private void saveInventory() {
        try {
            ObjectOutputStream oos =
                new ObjectOutputStream(new FileOutputStream(FILE_NAME));
            oos.writeObject(inventory);
            oos.close();
        } catch (Exception e) {
            System.out.println("Error saving data");
        }
    }

    private List<InventoryItem> loadInventory() {
        try {
            ObjectInputStream ois =
                new ObjectInputStream(new FileInputStream(FILE_NAME));
            return (List<InventoryItem>) ois.readObject();
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        InventoryManager manager = new InventoryManager();

        while (true) {
            System.out.println("\n1.Add 2.Update 3.Delete 4.View 5.Exit");
            int ch = sc.nextInt();

            switch (ch) {
                case 1:
                    System.out.print("ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Name: ");
                    String name = sc.nextLine();
                    System.out.print("Quantity: ");
                    int qty = sc.nextInt();
                    manager.addItem(id, name, qty);
                    break;

                case 2:
                    System.out.print("ID: ");
                    id = sc.nextInt();
                    System.out.print("New Quantity: ");
                    qty = sc.nextInt();
                    manager.updateItem(id, qty);
                    break;

                case 3:
                    System.out.print("ID: ");
                    id = sc.nextInt();
                    manager.deleteItem(id);
                    break;

                case 4:
                    manager.displayItems();
                    break;

                case 5:
                    return;
            }
        }
    }
}
