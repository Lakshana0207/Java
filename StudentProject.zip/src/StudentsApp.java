import com.example.students.Students;
import java.util.ArrayList;
import java.util.Scanner;

public class StudentsApp {
    private static final ArrayList<Students> students = new ArrayList<>();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n1. Add Student\n2. View Students\n3. Exit");

            switch (scanner.nextInt()) {
                case 1:
                    addStudent();
                    break;
                case 2:
                    viewStudents();
                    break;
                case 3:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice");
            }
        }
    }

    private static void addStudent() {
        scanner.nextLine();
        System.out.print("Enter Name: ");
        String name = scanner.nextLine();

        System.out.print("Enter Age: ");
        int age = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter ID: ");
        String id = scanner.nextLine();

        students.add(new Students(name, age, id));
    }

    private static void viewStudents() {
        if (students.isEmpty()) {
            System.out.println("No students found.");
        } else {
            for (Students s : students) {
                s.displayDetails();
            }
        }
    }
}
